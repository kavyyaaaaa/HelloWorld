package org.tnsif.sf.c2tc.junior_developers;

public class Kia_speedlimit {
	
	 public void disp_speedlimit()
	{
		System.out.println("All KIA have speedlimit");
	}
	 public static void main(String[] args) {
			Kia_speedlimit obj=new Kia_speedlimit();
			obj.disp_speedlimit();

}
}