package org.tnsif.sf.c2tc.basicsjava;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World");
	}

}
