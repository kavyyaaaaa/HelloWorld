package org.tnsif.sf.c2tc.sr_developers;
import org.tnsif.sf.c2tc.junior_developers.*;
public class Kia_Internal extends Kia_speedlimit {

	public static void main(String[] args) {
		
		Kia_speedlimit obj1=new Kia_speedlimit();
		obj1.disp_speedlimit();
	}

}
