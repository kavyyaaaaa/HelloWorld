package org.tnsif.sf.c2tc.oops;
class Add
{
	int a=3;
	int b=8;
	void add()
	{
		System.out.println(a+b);
	}
}
public class demo {

	public static void main(String[] args) {
		Add a1=new Add();
		a1.add();

	}

}
