package org.tnsif.sf.c2tc.finaldemo;
//Government ID generator


final class AadhaarGenerator
{
	void generateID()
	{
		System.out.println("Generated Aadhaar card ");
	}
}
class Myaadhar extends AadhaarGenerator
{
	
}

public class FinalClassDemo {

	public static void main(String[] args) {
		
	}

}
