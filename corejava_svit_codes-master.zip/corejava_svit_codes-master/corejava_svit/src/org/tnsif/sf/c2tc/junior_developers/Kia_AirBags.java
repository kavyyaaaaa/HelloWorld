package org.tnsif.sf.c2tc.junior_developers;

public class Kia_AirBags {

	public static void main(String[] args) {
		Kia_speedlimit obj=new Kia_speedlimit();
		obj.disp_speedlimit();
	}
//	public void disp_airbags()
//	{
//		System.out.println("All Kia have airbags");
//	}
}
