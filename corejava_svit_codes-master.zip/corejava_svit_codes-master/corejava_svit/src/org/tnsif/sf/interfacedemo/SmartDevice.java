package org.tnsif.sf.interfacedemo;

public interface SmartDevice {
	public abstract void turnOn();
	public abstract void turnOff();
	public abstract void getStatus();


}
