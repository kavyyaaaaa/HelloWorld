package org.tnsif.sf.interfacedemo;

public interface Registerable {

}
