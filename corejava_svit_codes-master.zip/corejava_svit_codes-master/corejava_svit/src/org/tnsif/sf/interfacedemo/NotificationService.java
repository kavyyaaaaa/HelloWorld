package org.tnsif.sf.interfacedemo;

@FunctionalInterface
public interface NotificationService {
  void notifyUser(String message);

}
